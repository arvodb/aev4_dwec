import { Component } from '@angular/core';

@Component({
  selector: 'app-game-three',
  templateUrl: './game-three.component.html',
  styleUrls: ['./game-three.component.css']
})
export class GameThreeComponent {

}
